<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
		body {
            /* pour changer la couler bleu qui est en bacground */
			background-color: #FFD700;
		}
		
		form {
			margin: 0 auto;
			width: 30%;
            /* pour changer la couler blanche du formulaire qui est en bacground */
			background-color: #E18141;
			padding: 50px;
			border-radius: 5px;
			box-shadow: 0px 0px 5px 0px rgba(0,0,0,0.2);
		}

            /* pour changer les inputs du formulaire */
        input[type=text], input[type=number], select {
			width: 100%;
			padding: 12px 20px;
			margin: 8px 0;
			display: inline-block;
			border: 1px solid #ccc;
			border-radius: 4px;
			box-sizing: border-box;
		}
		
		input[type=submit] {
			background-color: #4CAF50;
			color: white;
			/* padding: 12px 20px; */
			border: none;
			border-radius: 4px;
			cursor: pointer;
			width: 100%;
            border: none;
            border-radius: 3px;
            padding-right: 70px;
            cursor: pointer;
            /* margin: 20px; */
            
		}
        input[type=reset] {
			background-color: #D10000;
			color: white;
            /* margin-top: 20px; */
			padding: 12px 20px;
			border: none;
			border-radius: 4px;
			cursor: pointer;
			width: 100%;
            border: none;
            border-radius: 3px;
            padding: 10px 20px;
            cursor: pointer;
		}
		
		input[type=submit]:hover {
			background-color: #45a049;
		}
        input[type=reset]:hover {
			background-color: #E1C441;
		}
        .buttons {
            display: flex;
            justify-content: space-between;
            width: 100%;
        }
	</style>
</head>
<body>
    <form action="http://localhost/L3IAGE/Epidemia/src/controller/PersonneController.php" method="post">
        <div>
            <label for="">Nom : </label>
            <input type="text" name="nomP"  placeholder="Entrer le Nom" />
        </div>
        <div>
            <label for="">Prenom : </label>
            <input type="text" name="prenomP"  placeholder="Entrer le Prénom" />
           
        </div>
        <div>
            <label for="">Numero de telephone : </label>
            <input type="number" name="numTel"  placeholder="Entrer le Numéro de Téléphone" />
        </div>
        <div>
            <label for="">Adresse : </label>
            <input type="text" name="adresse"  placeholder="Entrer l'adresse" />
        </div>
        <div>
            <label for="">Sexe : </label>
            <input type="text" name="sexe"  placeholder="Entrer son genre" />
        </div>
        <div>
            <label for="">Résultat: </label>
            <select name="résultat"> 
            <option value="">Choisir parmi ces resultats</option>
                <option value="positive"> positive </option>
                <option value="négative"> négative</option>
                <option value="symptômatique">symptômatique</option>
            </select>
        </div>
       
        <div class="buttons">
            <input type="submit" name="submit" value="Register"/>
            <input type="reset" name="reset" value="Cancel"/>
        </div>
    </form>
</body>
</html>