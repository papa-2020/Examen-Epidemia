<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Point de surveillance Registration</title>
    <style>
		body {
            /* pour changer la couler bleu qui est en bacground */
			background-color: #FFD700;
		}
		
		form {
			margin: 0 auto;
			width: 30%;
            /* pour changer la couler blanche du formulaire qui est en bacground */
			background-color: #E18141;
			padding: 50px;
			border-radius: 5px;
			box-shadow: 0px 0px 5px 0px rgba(0,0,0,0.2);
		}

            /* pour changer les inputs du formulaire */
        input[type=text], input[type=number], select {
			width: 100%;
			padding: 12px 20px;
			margin: 8px 0;
			display: inline-block;
			border: 1px solid #ccc;
			border-radius: 4px;
			box-sizing: border-box;
		}
		
		input[type=submit] {
			background-color: #4CAF50;
			color: white;
			/* padding: 12px 20px; */
			border: none;
			border-radius: 4px;
			cursor: pointer;
			width: 100%;
            border: none;
            border-radius: 3px;
            padding-right: 70px;
            cursor: pointer;
            /* margin: 20px; */
            
		}
        input[type=reset] {
			background-color: #D10000;
			color: white;
            /* margin-top: 20px; */
			padding: 12px 20px;
			border: none;
			border-radius: 4px;
			cursor: pointer;
			width: 100%;
            border: none;
            border-radius: 3px;
            padding: 10px 20px;
            cursor: pointer;
		}
		
		input[type=submit]:hover {
			background-color: #A09245;
		}
        input[type=reset]:hover {
			background-color: #E1C441;
		}
        .buttons {
            display: flex;
            justify-content: space-between;
            width: 100%;
        }
	</style>
</head>
<body>
    <form action="http://localhost:8080/Epidemia/src/controller/PointSController.php" method="post">
        <div>
            <label for="">Nom PointS : </label>
            <input type="text" name="nom"/>
        </div>
        
        
       
        <div>
            <input type="submit" name="submit" value="Register"/>
            <input type="reset" name="reset" value="Cancel"/>
        </div>
    </form>
</body>
</html>