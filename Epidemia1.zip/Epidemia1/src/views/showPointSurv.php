<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
		body {
            /* pour changer la couler bleu qui est en bacground */
			background-color: #E1DE41;
		}
		
		form {
			margin: 0 auto;
			width: 30%;
            /* pour changer la couler blanche du formulaire qui est en bacground */
			background-color: #E18141;
			padding: 50px;
			border-radius: 5px;
			box-shadow: 0px 0px 5px 0px rgba(0,0,0,0.2);
		}

            /* pour changer les inputs du formulaire */
        input[type=text], input[type=number], select {
			width: 100%;
			padding: 12px 20px;
			margin: 8px 0;
			display: inline-block;
			border: 1px solid #ccc;
			border-radius: 4px;
			box-sizing: border-box;
		}
		
		input[type=submit] {
			background-color: #4CAF50;
			color: white;
			/* padding: 12px 20px; */
			border: none;
			border-radius: 4px;
			cursor: pointer;
			width: 100%;
            border: none;
            border-radius: 3px; 
            padding-right: 70px;
            cursor: pointer;
            /* margin: 20px; */
            
		}
        input[type=reset] {
			background-color: #D10000;
			color: white;
            /* margin-top: 20px; */
			padding: 12px 20px;
			border: none;
			border-radius: 4px;
			cursor: pointer;
			width: 100%;
            border: none;
            border-radius: 3px;
            padding: 10px 20px;
            cursor: pointer;
		}
		
		input[type=submit]:hover {
			background-color: #45a049;
		}
        input[type=reset]:hover {
			background-color: #DEE141;
		}
        .buttons {
            display: flex;
            justify-content: space-between;
            width: 100%;
        }
	</style>
</head>
<body>
    <table>
        <tr>
            <th>Nom PointSurv :</th>
                 
        </tr>
        <?php 
            include_once "../repository/Fonction.php";

            $edb = new Fonction();

            $PointSurv = $edb->getAllPointSurv();

            foreach ($PointSurv as $pointSurv) 
            {
                echo "<tr>
                        <td>$pointSurv[1]</td>
                    </tr>";
            }
        ?>
    </table>
</body>
</html>