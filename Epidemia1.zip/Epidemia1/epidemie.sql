-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : ven. 24 mars 2023 à 05:45
-- Version du serveur :  10.4.17-MariaDB
-- Version de PHP : 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `virus`
--

-- --------------------------------------------------------

--
-- Structure de la table `pays`
--

CREATE TABLE `pays` (
  `idPays` int(20) NOT NULL,
  `nom` varchar(30) NOT NULL,
  `population` int(6) NOT NULL,
  `listezone` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `pays`
--

INSERT INTO `pays` (`idPays`, `nom`, `population`, `listezone`) VALUES
(1, 'Senegal', 100000, 'fchg'),
(2, 'Senegal', 100000, 'fchg'),
(3, 'Senegal', 100000, 'fchg'),
(4, 'Senegal', 100000, 'fchg'),
(7, 'Senegal', 1986, 'mpc');

-- --------------------------------------------------------

--
-- Structure de la table `personne`
--

CREATE TABLE `personne` (
  `idPersonne` int(10) NOT NULL,
  `nomP` varchar(20) NOT NULL,
  `prenomP` varchar(30) NOT NULL,
  `numTel` int(20) NOT NULL,
  `adresse` varchar(100) NOT NULL,
  `sexe` varchar(10) NOT NULL,
  `résultat` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `personne`
--

INSERT INTO `personne` (`idPersonne`, `nomP`, `prenomP`, `numTel`, `adresse`, `sexe`, `résultat`) VALUES
(1, 'Mariama', '', 7809876, 'Pikine', 'Femme', ''),
(2, 'Mariama', '', 7809876, 'Pikine', 'Femme', ''),
(3, '', '', 0, '', '', ''),
(4, '', '', 0, '', '', ''),
(5, 'Moussa', '', 77789877, 'Pikine', 'Homme', ''),
(6, 'abdoulaye', '', 667896567, 'Pikine', 'Homme', 'négative'),
(7, 'maman', '', 2147483647, 'mamelles', 'femme', 'positive'),
(8, 'laye', '', 2147483647, 'mamelles', 'femme', 'négative'),
(9, 'Moussa', '', 777653421, 'keur massar', 'Homme', 'positive'),
(10, 'amy', '', 771674077, 'ouakam', 'femme', 'négative'),
(11, 'sylla', 'mariama', 55679764, 'louga', 'femme', 'symptômatique'),
(12, 'leye', 'babacar', 781132618, 'Bountou Pikine', 'Homme', 'symptômatique'),
(13, 'diallo', 'binta', 2147483647, 'ouakam', 'femme', 'positive'),
(14, 'dieye', 'skzpkok', 56789, 'chjnk,l', 'rtyguhijk', 'positive'),
(15, 'dieye', 'skzpkok', 56789, 'chjnk,l', 'rtyguhijk', 'positive'),
(16, 'dieye', 'skzpkok', 56789, 'chjnk,l', 'rtyguhijk', 'positive'),
(17, 'dieye', 'skzpkok', 56789, 'chjnk,l', 'rtyguhijk', 'positive'),
(18, 'dfghj', 'ghj', 4567890, 'rtghjkl', 'ghjkl', 'positive'),
(19, 'dfghj', 'ghj', 4567890, 'rtghjkl', 'ghjkl', 'positive'),
(20, 'bnlkj', 'klknbn', 67890, 'ghj', 'vb', 'positive'),
(21, 'bnn', 'ni', 6789, 'hjk', 'bnjk', 'positive'),
(22, 'pokjn', 'klmlkn', 9876, 'cvbn', 'bn', 'positive'),
(23, 'Diop', 'Moussa', 3456789, 'Pikine', 'Homme', 'positive'),
(24, 'Diop', 'Moussa', 3456789, 'Pikine', 'Homme', 'positive'),
(25, 'Diop1', 'Moussa1', 3456789, 'Pikine', 'Homme', 'positive');

-- --------------------------------------------------------

--
-- Structure de la table `pointsureveiller`
--

CREATE TABLE `pointsureveiller` (
  `idPoint` int(10) NOT NULL,
  `nom` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `pointsureveiller`
--

INSERT INTO `pointsureveiller` (`idPoint`, `nom`) VALUES
(1, 'yoff'),
(2, 'yoff');

-- --------------------------------------------------------

--
-- Structure de la table `zones`
--

CREATE TABLE `zones` (
  `idZone` int(10) NOT NULL,
  `nom` varchar(30) NOT NULL,
  `nombreps` varchar(200) NOT NULL,
  `nombrepp` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `zones`
--

INSERT INTO `zones` (`idZone`, `nom`, `nombreps`, `nombrepp`) VALUES
(1, 'Dakar', '12', '12'),
(2, 'Dakar', '12', '2'),
(3, '', '', '');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `pays`
--
ALTER TABLE `pays`
  ADD PRIMARY KEY (`idPays`);

--
-- Index pour la table `personne`
--
ALTER TABLE `personne`
  ADD PRIMARY KEY (`idPersonne`);

--
-- Index pour la table `pointsureveiller`
--
ALTER TABLE `pointsureveiller`
  ADD PRIMARY KEY (`idPoint`);

--
-- Index pour la table `zones`
--
ALTER TABLE `zones`
  ADD PRIMARY KEY (`idZone`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `pays`
--
ALTER TABLE `pays`
  MODIFY `idPays` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `personne`
--
ALTER TABLE `personne`
  MODIFY `idPersonne` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT pour la table `pointsureveiller`
--
ALTER TABLE `pointsureveiller`
  MODIFY `idPoint` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `zones`
--
ALTER TABLE `zones`
  MODIFY `idZone` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
